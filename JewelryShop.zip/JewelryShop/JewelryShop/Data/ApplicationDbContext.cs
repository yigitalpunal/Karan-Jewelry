﻿using Microsoft.EntityFrameworkCore;
using JewelryShop.Models;

namespace JewelryShop.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Product> Products => Set<Product>();
        // Diğer DbSet'leri buraya ekle (örneğin: public DbSet<Category> Categories => Set<Category>();)
    }
}
