﻿using JewelryShop.Models;
using Microsoft.EntityFrameworkCore;

namespace JewelryShop.Data
{
    public static class SeedData
    {
        public static void Initialize(ApplicationDbContext context)
        {
            if (context.Products.Any()) return; // Zaten ürün varsa geç

            context.Products.AddRange(
                new Product
                {
                    Name = "Personal Message Bracelet",
                    Description = "A special bracelet with a personal message.",
                    Price = 190.00m,
                    ImageUrl = "/images/Bilezik1.png",
                    Category = "Bracelet",
                    Material = "Stainless steel",
                    CareInstructions = "Wipe with a dry cloth, avoid contact with water.",
                    UsageTip = "Ideal for daily use."
                },
                new Product
                {
                    Name = "Personalized Name Necklace",
                    Description = "A unique necklace with a personalized name design.",
                    Price = 180.00m,
                    ImageUrl = "/images/Kolye1.png",
                    Category = "Necklace",
                    Material = "Gold plated",
                    CareInstructions = "Avoid contact with perfume.",
                    UsageTip = "A stylish complement for special occasions."
                },
                new Product
                {
                    Name = "Classic Gold Bracelet",
                    Description = "A classic gold bracelet design.",
                    Price = 300.00m,
                    ImageUrl = "/images/Bilezik2.png",
                    Category = "Bracelet",
                    Material = "14 Karat Gold",
                    CareInstructions = "Clean with mild soap.",
                    UsageTip = "Perfect for those who love traditional styles."
                },
                new Product
                {
                    Name = "Emerald Stone Ring",
                    Description = "A stylish ring decorated with an emerald stone.",
                    Price = 250.00m,
                    ImageUrl = "/images/Yuzuk1.png",
                    Category = "Ring",
                    Material = "Silver and emerald",
                    CareInstructions = "Avoid chemical cleaners.",
                    UsageTip = "Complements elegance at dinner events."
                },
                new Product
                {
                    Name = "Elegant Pearl Necklace",
                    Description = "An elegant necklace designed with pearl details.",
                    Price = 150.00m,
                    ImageUrl = "/images/Kolye2.png",
                    Category = "Necklace",
                    Material = "Pearl and silver",
                    CareInstructions = "Avoid contact with perfume.",
                    UsageTip = "Ideal for office elegance."
                },
                new Product
                {
                    Name = "Colorful Stone Bracelet",
                    Description = "A stylish bracelet adorned with colorful stones.",
                    Price = 220.00m,
                    ImageUrl = "/images/Bilezik3.png",
                    Category = "Bracelet",
                    Material = "Metal and synthetic stone",
                    CareInstructions = "Avoid contact with water.",
                    UsageTip = "Adds energy to summer outfits."
                },
                new Product
                {
                    Name = "Gold Plated Necklace",
                    Description = "A necklace offering an elegant look with gold plating.",
                    Price = 200.00m,
                    ImageUrl = "/images/Kolye3.png",
                    Category = "Necklace",
                    Material = "Gold plated",
                    CareInstructions = "Clean with a dry cloth.",
                    UsageTip = "Combine with classic dresses."
                },
                new Product
                {
                    Name = "Heart Shaped Ring",
                    Description = "A romantic ring designed in the shape of a heart.",
                    Price = 160.00m,
                    ImageUrl = "/images/Yuzuk2.png",
                    Category = "Ring",
                    Material = "Silver",
                    CareInstructions = "Do not leave in humid environments.",
                    UsageTip = "A perfect gift for Valentine's Day."
                },
                new Product
                {
                    Name = "Silver Minimal Ring",
                    Description = "A silver ring with a minimal design.",
                    Price = 120.00m,
                    ImageUrl = "/images/Yuzuk3.png",
                    Category = "Ring",
                    Material = "925 Sterling Silver",
                    CareInstructions = "Gently wipe with a dry cloth.",
                    UsageTip = "Matches every outfit."
                }
            );

            context.SaveChanges();
        }
    }
}
