using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace JewelryShop.Views.Cart
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
