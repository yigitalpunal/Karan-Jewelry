using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace JewelryShop.Views.Cart
{
    public class Index1Model : PageModel
    {
        public void OnGet()
        {
        }
    }
}
