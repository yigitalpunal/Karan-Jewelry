﻿using System;

namespace JewelryShop.Models
{
    [Serializable]
    public class CartItem
    {
        public Product Product { get; set; } = null!;
        public int Quantity { get; set; }  // ← bu satır çok önemli
    }
}
