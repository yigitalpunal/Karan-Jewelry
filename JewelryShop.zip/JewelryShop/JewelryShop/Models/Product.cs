﻿using System.ComponentModel.DataAnnotations;

namespace JewelryShop.Models
{
    public class Product
    {
        public int Id { get; set; }

        [Required]
        public string Name { get; set; } = string.Empty;

        public string Description { get; set; } = string.Empty;

        public string ImageUrl { get; set; } = string.Empty;

        public string Category { get; set; } = string.Empty;

        public decimal Price { get; set; }

        // 🆕 Yeni Eklenen Alanlar
        public string Material { get; set; } = string.Empty;

        public string CareInstructions { get; set; } = string.Empty;

        public string UsageTip { get; set; } = string.Empty;
    }
}
