﻿// 1. OrderViewModel.cs
using System.ComponentModel.DataAnnotations;

namespace JewelryShop.Models
{
    public class OrderViewModel
    {
        [Required(ErrorMessage = "Adınızı girin")]
        public string FullName { get; set; } = string.Empty;

        [Required(ErrorMessage = "Adres bilgisi zorunlu")]
        public string Address { get; set; } = string.Empty;

        [Required(ErrorMessage = "E-posta adresi gerekli")]
        [EmailAddress]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "Telefon numarası gerekli")]
        [Phone]
        public string Phone { get; set; } = string.Empty;
    }
}
