﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;

namespace JewelryShop.Controllers
{
    public class CheckoutController : Controller
    {
        // Adres giriş sayfası (Views/Checkout/Checkout.cshtml)
        public IActionResult Checkout()
        {
            return View();
        }

        // Adres formu gönderilince çağrılır
        [HttpPost]
        public IActionResult Checkout(string adSoyad, string adres, string sehir)
        {
            HttpContext.Session.SetString("AdSoyad", adSoyad);
            HttpContext.Session.SetString("Adres", adres);
            HttpContext.Session.SetString("Sehir", sehir);

            return RedirectToAction("Index");
        }

        // Ödeme formu (Views/Checkout/Index.cshtml)
        public IActionResult Index()
        {
            return View();
        }

        // Ödeme formu gönderildiğinde çalışır
        [HttpPost]
        public IActionResult Process(string cardName, string cardNumber, string expiry, string cvv)
        {
            if (string.IsNullOrWhiteSpace(cardNumber) || cardNumber.Length < 12)
            {
                ViewBag.Error = "Kart numarası geçersiz!";
                return View("Index");
            }

            return RedirectToAction("Success");
        }

        // Başarı ekranı (Views/Checkout/Success.cshtml)
        public IActionResult Success()
        {
            return View();
        }
    }
}
