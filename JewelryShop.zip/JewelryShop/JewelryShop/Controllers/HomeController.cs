using System.Diagnostics;
using JewelryShop.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;

namespace JewelryShop.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        // Product list (same as in ProductController)
        private readonly List<Product> products = new()
        {
            new Product
            {
                Id = 1,
                Name = "Personalized Message Bracelet",
                Description = "A special bracelet with a customizable message.",
                Price = 190.00m,
                ImageUrl = "/images/Bilezik1.png",
                Category = "Bracelet"
            },
            new Product
            {
                Id = 2,
                Name = "Personalized Name Necklace",
                Description = "A necklace with a custom name design.",
                Price = 180.00m,
                ImageUrl = "/images/Kolye1.png",
                Category = "Necklace"
            },
            new Product
            {
                Id = 3,
                Name = "Classic Gold Bracelet",
                Description = "A classic design gold bracelet.",
                Price = 300.00m,
                ImageUrl = "/images/Bilezik2.png",
                Category = "Bracelet"
            },
            new Product
            {
                Id = 4,
                Name = "Emerald Stone Ring",
                Description = "A stylish ring adorned with an emerald stone.",
                Price = 250.00m,
                ImageUrl = "/images/Yuzuk1.png",
                Category = "Ring"
            },
            new Product
            {
                Id = 5,
                Name = "Elegant Pearl Necklace",
                Description = "An elegant necklace designed with stylish pearl details.",
                Price = 150.00m,
                ImageUrl = "/images/Kolye2.png",
                Category = "Necklace"
            },
            new Product
            {
                Id = 6,
                Name = "Colorful Stone Bracelet",
                Description = "A stylish bracelet adorned with colorful stones.",
                Price = 220.00m,
                ImageUrl = "/images/Bilezik3.png",
                Category = "Bracelet"
            },
            new Product
            {
                Id = 7,
                Name = "Gold Plated Necklace",
                Description = "A necklace offering an elegant look with gold plating.",
                Price = 200.00m,
                ImageUrl = "/images/Kolye3.png",
                Category = "Necklace"
            },
            new Product
            {
                Id = 8,
                Name = "Heart Shaped Ring",
                Description = "A romantic ring designed in the shape of a heart.",
                Price = 160.00m,
                ImageUrl = "/images/Yuzuk2.png",
                Category = "Ring"
            },
            new Product
            {
                Id = 9,
                Name = "Silver Minimal Ring",
                Description = "A silver ring with a minimal design.",
                Price = 120.00m,
                ImageUrl = "/images/Yuzuk3.png",
                Category = "Ring"
            }
        };

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        // Homepage with product list
        public IActionResult Index()
        {
            return View(products);
        }

        // Static informational pages
        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Accessibility()
        {
            return View();
        }

        public IActionResult Shipping()
        {
            return View();
        }

        public IActionResult Terms()
        {
            return View();
        }

        public IActionResult Return()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
