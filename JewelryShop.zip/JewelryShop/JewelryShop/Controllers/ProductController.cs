﻿using Microsoft.AspNetCore.Mvc;
using JewelryShop.Models;
using JewelryShop.Data;
using System.Collections.Generic;
using System.Linq;

namespace JewelryShop.Controllers
{
    public class ProductController : Controller
    {
        private readonly ApplicationDbContext _context;

        public ProductController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Hardcoded fallback list
        private readonly List<Product> fallbackProducts = new()
        {
            new Product {
                Id = 1,
                Name = "Personal Message Bracelet",
                Description = "A special bracelet with a personal message.",
                Price = 190.00m,
                ImageUrl = "/images/Bilezik1.png",
                Category = "Bracelet",
                Material = "Stainless steel",
                CareInstructions = "Wipe with a dry cloth, avoid contact with water.",
                UsageTip = "Ideal for daily use."
            },
            new Product {
                Id = 2,
                Name = "Personalized Name Necklace",
                Description = "A unique necklace with a personalized name design.",
                Price = 180.00m,
                ImageUrl = "/images/Kolye1.png",
                Category = "Necklace",
                Material = "Gold plated",
                CareInstructions = "Avoid contact with perfume.",
                UsageTip = "A stylish complement for special occasions."
            },
            new Product {
                Id = 3,
                Name = "Classic Gold Bracelet",
                Description = "A classic gold bracelet design.",
                Price = 300.00m,
                ImageUrl = "/images/Bilezik2.png",
                Category = "Bracelet",
                Material = "14 Karat Gold",
                CareInstructions = "Clean with mild soap.",
                UsageTip = "Perfect for those who love traditional styles."
            },
            new Product {
                Id = 4,
                Name = "Emerald Stone Ring",
                Description = "A stylish ring decorated with an emerald stone.",
                Price = 250.00m,
                ImageUrl = "/images/Yuzuk1.png",
                Category = "Ring",
                Material = "Silver and emerald",
                CareInstructions = "Avoid chemical cleaners.",
                UsageTip = "Complements elegance at dinner events."
            },
            new Product {
                Id = 5,
                Name = "Elegant Pearl Necklace",
                Description = "An elegant necklace designed with pearl details.",
                Price = 150.00m,
                ImageUrl = "/images/Kolye2.png",
                Category = "Necklace",
                Material = "Pearl and silver",
                CareInstructions = "Avoid contact with perfume.",
                UsageTip = "Ideal for office elegance."
            },
            new Product {
                Id = 6,
                Name = "Colorful Stone Bracelet",
                Description = "A stylish bracelet adorned with colorful stones.",
                Price = 220.00m,
                ImageUrl = "/images/Bilezik3.png",
                Category = "Bracelet",
                Material = "Metal and synthetic stone",
                CareInstructions = "Avoid contact with water.",
                UsageTip = "Adds energy to summer outfits."
            },
            new Product {
                Id = 7,
                Name = "Gold Plated Necklace",
                Description = "A necklace offering an elegant look with gold plating.",
                Price = 200.00m,
                ImageUrl = "/images/Kolye3.png",
                Category = "Necklace",
                Material = "Gold plated",
                CareInstructions = "Clean with a dry cloth.",
                UsageTip = "Combine with classic dresses."
            },
            new Product {
                Id = 8,
                Name = "Heart Shaped Ring",
                Description = "A romantic ring designed in the shape of a heart.",
                Price = 160.00m,
                ImageUrl = "/images/Yuzuk2.png",
                Category = "Ring",
                Material = "Silver",
                CareInstructions = "Do not leave in humid environments.",
                UsageTip = "A perfect gift for Valentine's Day."
            },
            new Product {
                Id = 9,
                Name = "Silver Minimal Ring",
                Description = "A silver ring with a minimal design.",
                Price = 120.00m,
                ImageUrl = "/images/Yuzuk3.png",
                Category = "Ring",
                Material = "925 Sterling Silver",
                CareInstructions = "Gently wipe with a dry cloth.",
                UsageTip = "Matches every outfit."
            }
        };

        public IActionResult Index(string category, string search, string sort)
        {
            var dbProducts = _context.Products.ToList();
            var products = dbProducts.Count > 0 ? dbProducts : fallbackProducts;

            ViewBag.SelectedCategory = category;
            ViewBag.Categories = products.Select(p => p.Category).Distinct().ToList();
            ViewBag.SearchTerm = search;
            ViewBag.Sorting = sort;

            var filtered = products.AsEnumerable();

            if (!string.IsNullOrEmpty(category))
                filtered = filtered.Where(p => p.Category == category);

            if (!string.IsNullOrEmpty(search))
                filtered = filtered.Where(p =>
                    p.Name.ToLower().Contains(search.ToLower()) ||
                    p.Description.ToLower().Contains(search.ToLower()));

            filtered = sort switch
            {
                "fiyat-asc" => filtered.OrderBy(p => p.Price),
                "fiyat-desc" => filtered.OrderByDescending(p => p.Price),
                "isim-asc" => filtered.OrderBy(p => p.Name),
                "isim-desc" => filtered.OrderByDescending(p => p.Name),
                _ => filtered
            };

            return View(filtered.ToList());
        }

        public IActionResult Details(int id)
        {
            var dbProducts = _context.Products.ToList();
            var products = dbProducts.Count > 0 ? dbProducts : fallbackProducts;

            var product = products.FirstOrDefault(p => p.Id == id);
            if (product == null)
                return NotFound();

            var nextProduct = products.OrderBy(p => p.Id).FirstOrDefault(p => p.Id > id);
            var prevProduct = products.OrderByDescending(p => p.Id).FirstOrDefault(p => p.Id < id);

            ViewBag.NextId = nextProduct?.Id;
            ViewBag.PrevId = prevProduct?.Id;

            return View(product);
        }
    }
}
