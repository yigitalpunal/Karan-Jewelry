﻿using Microsoft.AspNetCore.Mvc;
using JewelryShop.Models;
using Microsoft.AspNetCore.Http;
using JewelryShop.Extensions;
using System.Collections.Generic;
using System.Linq;

namespace JewelryShop.Controllers
{
    public class CartController : Controller
    {
        private readonly List<Product> products = new()
        {
            new Product { Id = 1, Name = "Personalized Message Bracelet", Description = "A special bracelet with a customizable message.", Price = 190.00m, ImageUrl = "/images/Bilezik1.png", Category = "Bracelet" },
            new Product { Id = 2, Name = "Personalized Name Necklace", Description = "A necklace with a custom name design.", Price = 180.00m, ImageUrl = "/images/Kolye1.png", Category = "Necklace" },
            new Product { Id = 3, Name = "Classic Gold Bracelet", Description = "A gold bracelet with a classic design.", Price = 300.00m, ImageUrl = "/images/Bilezik2.png", Category = "Bracelet" },
            new Product { Id = 4, Name = "Emerald Stone Ring", Description = "A stylish ring adorned with an emerald stone.", Price = 250.00m, ImageUrl = "/images/Yuzuk1.png", Category = "Ring" },
            new Product { Id = 5, Name = "Elegant Pearl Necklace", Description = "An elegant necklace designed with stylish pearl details.", Price = 150.00m, ImageUrl = "/images/Kolye2.png", Category = "Necklace" },
            new Product { Id = 6, Name = "Colorful Stone Bracelet", Description = "A stylish bracelet adorned with colorful stones.", Price = 220.00m, ImageUrl = "/images/Bilezik3.png", Category = "Bracelet" },
            new Product { Id = 7, Name = "Gold Plated Necklace", Description = "A necklace with an elegant look thanks to gold plating.", Price = 200.00m, ImageUrl = "/images/Kolye3.png", Category = "Necklace" },
            new Product { Id = 8, Name = "Heart Shaped Ring", Description = "A romantic ring designed in the shape of a heart.", Price = 160.00m, ImageUrl = "/images/Yuzuk2.png", Category = "Ring" },
            new Product { Id = 9, Name = "Minimal Silver Ring", Description = "A silver ring with a minimal design.", Price = 120.00m, ImageUrl = "/images/Yuzuk3.png", Category = "Ring" }
        };

        public IActionResult Index()
        {
            var cart = HttpContext.Session.GetObjectFromJson<List<CartItem>>("Sepet") ?? new List<CartItem>();
            return View(cart);
        }

        [HttpPost]
        public IActionResult Ekle(int productId, int adet)
        {
            var cart = HttpContext.Session.GetObjectFromJson<List<CartItem>>("Sepet") ?? new List<CartItem>();
            var product = products.FirstOrDefault(p => p.Id == productId);

            if (product != null)
            {
                var existingItem = cart.Find(x => x.Product.Id == productId);
                if (existingItem != null)
                {
                    existingItem.Quantity += adet;
                }
                else
                {
                    cart.Add(new CartItem { Product = product, Quantity = adet });
                }
            }

            HttpContext.Session.SetObjectAsJson("Sepet", cart);
            return RedirectToAction("Index");
        }

        public IActionResult Sil(int id)
        {
            var cart = HttpContext.Session.GetObjectFromJson<List<CartItem>>("Sepet") ?? new List<CartItem>();
            var item = cart.Find(x => x.Product.Id == id);
            if (item != null)
            {
                cart.Remove(item);
            }
            HttpContext.Session.SetObjectAsJson("Sepet", cart);
            return RedirectToAction("Index");
        }

        public IActionResult Arttir(int id)
        {
            var cart = HttpContext.Session.GetObjectFromJson<List<CartItem>>("Sepet") ?? new List<CartItem>();
            var item = cart.FirstOrDefault(x => x.Product.Id == id);
            if (item != null)
            {
                item.Quantity++;
            }
            HttpContext.Session.SetObjectAsJson("Sepet", cart);
            return RedirectToAction("Index");
        }

        public IActionResult Azalt(int id)
        {
            var cart = HttpContext.Session.GetObjectFromJson<List<CartItem>>("Sepet") ?? new List<CartItem>();
            var item = cart.FirstOrDefault(x => x.Product.Id == id);
            if (item != null)
            {
                item.Quantity--;
                if (item.Quantity <= 0)
                {
                    cart.Remove(item);
                }
            }
            HttpContext.Session.SetObjectAsJson("Sepet", cart);
            return RedirectToAction("Index");
        }

        public IActionResult Temizle()
        {
            HttpContext.Session.Remove("Sepet");
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Checkout()
        {
            var cart = HttpContext.Session.GetObjectFromJson<List<CartItem>>("Sepet") ?? new List<CartItem>();
            var list = cart.ToList();
            ViewBag.Sepet = list;
            ViewBag.ToplamTutar = list.Sum(x => x.Product.Price * x.Quantity);
            return View();
        }

        [HttpPost]
        public IActionResult Checkout(OrderViewModel model)
        {
            var cart = HttpContext.Session.GetObjectFromJson<List<CartItem>>("Sepet") ?? new List<CartItem>();
            var list = cart.ToList();

            if (!ModelState.IsValid || !list.Any())
            {
                ViewBag.Sepet = list;
                ViewBag.ToplamTutar = list.Sum(x => x.Product.Price * x.Quantity);
                return View(model);
            }

            HttpContext.Session.Remove("Sepet");
            TempData["SiparisMesaj"] = "Your order has been placed successfully!";
            return RedirectToAction("SiparisOnay");
        }

        public IActionResult SiparisOnay()
        {
            return View();
        }
    }
}
